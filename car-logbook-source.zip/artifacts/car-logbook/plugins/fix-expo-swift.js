const fs = require("fs");
const path = require("path");

const SWIFT_PATCHES = [
  {
    rel: path.join(
      "expo-modules-core",
      "ios",
      "Core",
      "Events",
      "EventEmitter.swift"
    ),
    pairs: [
      [
        "nonisolated(unsafe) weak let emitter = self",
        "nonisolated(unsafe) weak var emitter = self",
      ],
    ],
  },
  {
    rel: path.join(
      "expo-modules-core",
      "ios",
      "Core",
      "SharedObjects",
      "SharedObjectRegistry.swift"
    ),
    pairs: [
      [
        "private weak let appContext: AppContext?",
        "private weak var appContext: AppContext?",
      ],
    ],
  },
];

function tryWriteFile(fp, content) {
  try {
    fs.writeFileSync(fp, content, "utf8");
    return true;
  } catch (_) {}
  try {
    fs.unlinkSync(fp);
    fs.writeFileSync(fp, content, "utf8");
    return true;
  } catch (_) {}
  return false;
}

function patchSwiftFile(fp) {
  let src;
  try {
    src = fs.readFileSync(fp, "utf8");
  } catch {
    return false;
  }
  let out = src;
  for (const { pairs } of SWIFT_PATCHES) {
    for (const [from, to] of pairs) {
      if (out.includes(from)) out = out.split(from).join(to);
    }
  }
  if (out === src) return false;
  return tryWriteFile(fp, out);
}

function patchInDir(nmDir, label) {
  let count = 0;
  for (const { rel } of SWIFT_PATCHES) {
    const fp = path.join(nmDir, rel);
    try {
      if (!fs.existsSync(fp)) continue;
      if (patchSwiftFile(fp)) {
        console.log("[fix-expo-swift] patched", rel, "via", label);
        count++;
      }
    } catch (e) {
      console.log("[fix-expo-swift] error on", fp, e.message);
    }
  }
  return count;
}

function patchNodeModules(projectRoot) {
  let total = 0;
  const seen = new Set();

  // 1. Try node_modules/expo-modules-core directly at multiple roots
  const nodeModulesRoots = [
    path.join(projectRoot, "..", "..", "node_modules"),   // workspace root (primary)
    path.join(projectRoot, "..", "node_modules"),          // artifacts/
    path.join(projectRoot, "node_modules"),                // car-logbook/
  ];
  for (const nmRoot of nodeModulesRoots) {
    const fp = path.join(nmRoot, "expo-modules-core", "ios", "Core", "Events", "EventEmitter.swift");
    try {
      if (!fs.existsSync(fp)) continue;
      let real = fp;
      try { real = fs.realpathSync(fp); } catch {}
      if (seen.has(real)) continue;
      seen.add(real);
      const n = patchInDir(nmRoot, "node_modules at " + nmRoot);
      total += n;
      if (n > 0) console.log("[fix-expo-swift] found packages at", nmRoot);
    } catch {}
  }

  // 2. Also search all .pnpm store dirs — skip candidates with no expo-modules-core entries
  const pnpmCandidates = [
    path.join(projectRoot, "..", "..", "node_modules", ".pnpm"),  // workspace root first
    path.join(projectRoot, "..", "node_modules", ".pnpm"),
    path.join(projectRoot, "node_modules", ".pnpm"),
  ];
  for (const storeDir of pnpmCandidates) {
    try {
      if (!fs.existsSync(storeDir)) continue;
      const entries = fs.readdirSync(storeDir).filter(e =>
        e.startsWith("expo-modules-core@57.0.6")
      );
      if (entries.length === 0) continue; // skip empty / non-matching stores
      console.log("[fix-expo-swift] .pnpm store:", storeDir, entries.length, "entries");
      for (const entry of entries) {
        const entryNm = path.join(storeDir, entry, "node_modules");
        for (const { rel } of SWIFT_PATCHES) {
          const fp = path.join(entryNm, rel);
          try {
            if (!fs.existsSync(fp)) continue;
            let real = fp;
            try { real = fs.realpathSync(fp); } catch {}
            if (seen.has(real)) { continue; }
            seen.add(real);
            if (patchSwiftFile(fp)) {
              console.log("[fix-expo-swift] pnpm patched", path.basename(fp), "in", entry.substring(0, 60));
              total++;
            }
          } catch (e) {
            console.log("[fix-expo-swift] pnpm error", fp, e.message);
          }
        }
      }
    } catch (e) {
      console.log("[fix-expo-swift] store error", storeDir, e.message);
    }
  }

  console.log("[fix-expo-swift] patchNodeModules total:", total);
  return total;
}

module.exports = function fixExpoSwiftPlugin(config) {
  try {
    const { withDangerousMod } = require("expo/config-plugins");
    return withDangerousMod(config, [
      "ios",
      (c) => {
        try {
          const n = patchNodeModules(c.modRequest.projectRoot);
          console.log("[fix-expo-swift] withDangerousMod done, patched", n);
        } catch (e) {
          console.log("[fix-expo-swift] error:", e.message);
        }
        return c;
      },
    ]);
  } catch (e) {
    console.log("[fix-expo-swift] withDangerousMod unavailable:", e.message);
    try {
      patchNodeModules(
        (config && config.modRequest && config.modRequest.projectRoot) ||
          process.cwd()
      );
    } catch {}
    return config;
  }
};
