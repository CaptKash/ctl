import { Feather } from "@expo/vector-icons";
import { MetalIcon } from "@/components/ui/MetalIcon";
import { useQuery } from "@tanstack/react-query";
import * as Haptics from "expo-haptics";
import { router } from "expo-router";
import React from "react";
import {
  ActivityIndicator,
  FlatList,
  Platform,
  Pressable,
  StyleSheet,
  Text,
  View,
} from "react-native";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useTranslation } from "react-i18next";
import { useColors } from "@/context/ThemeContext";
import { EmptyState } from "@/components/ui/EmptyState";
import { apiGet } from "@/hooks/useApi";

type Car = {
  id: number;
  make: string;
  model: string;
  year: number;
  licensePlate?: string | null;
};

export default function ReportsScreen() {
  const insets = useSafeAreaInsets();
  const C = useColors();
  const { t, i18n } = useTranslation();
  const isRTL = i18n.language === "ar";

  const { data: cars, isLoading } = useQuery<Car[]>({
    queryKey: ["cars"],
    queryFn: () => apiGet<Car[]>("/cars"),
  });

  const topPad = Platform.OS === "web" ? 67 : insets.top;
  const rtlText = isRTL ? { textAlign: "right" as const, writingDirection: "rtl" as const } : null;

  return (
    <View style={[styles.container, { backgroundColor: C.background }]}>
      <View style={[styles.header, { paddingTop: topPad + 12 }]}>
        <View>
          <Text style={[styles.headerEyebrow, { color: C.textSecondary }, rtlText]}>
            {t("reports.eyebrow")}
          </Text>
          <Text style={[styles.headerTitle, { color: C.text }, rtlText]}>
            {t("reports.title")}
          </Text>
        </View>
      </View>

      {isLoading ? (
        <View style={styles.loading}>
          <ActivityIndicator size="large" color={C.tint} />
        </View>
      ) : (
        <FlatList
          data={cars ?? []}
          keyExtractor={(item) => String(item.id)}
          contentContainerStyle={[
            styles.listContent,
            { paddingBottom: (Platform.OS === "web" ? 84 : insets.bottom) + 100 },
          ]}
          ListHeaderComponent={
            cars && cars.length > 0 ? (
              <Text style={[styles.sectionLabel, { color: C.textSecondary }, rtlText]}>
                {t("reports.selectCar")}
              </Text>
            ) : null
          }
          ListEmptyComponent={
            <EmptyState
              icon="bar-chart-2"
              title={t("reports.emptyTitle")}
              description={t("reports.emptyDesc")}
              actionLabel={t("reports.addCar")}
              onAction={() => router.push("/car/add")}
            />
          }
          renderItem={({ item }) => (
            <Pressable
              onPress={() => {
                Haptics.selectionAsync();
                router.push({ pathname: "/report/[id]", params: { id: String(item.id) } });
              }}
              style={({ pressed }) => [
                styles.reportCard,
                isRTL && { flexDirection: "row-reverse" },
                { backgroundColor: C.card, opacity: pressed ? 0.9 : 1 },
              ]}
            >
              <MetalIcon icon="file-text" color={C.info} bg={C.infoLight} size={22} style={styles.iconBox} />
              <View style={styles.cardText}>
                <Text style={[styles.carName, { color: C.text }, rtlText]}>
                  {item.year} {item.make} {item.model}
                </Text>
                {item.licensePlate && (
                  <Text style={[styles.plate, { color: C.textSecondary }, rtlText]}>
                    {item.licensePlate}
                  </Text>
                )}
              </View>
              <Feather
                name={isRTL ? "chevron-left" : "chevron-right"}
                size={18}
                color={C.textTertiary}
              />
            </Pressable>
          )}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  header: {
    paddingHorizontal: 20,
    paddingBottom: 16,
  },
  headerEyebrow: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
    textTransform: "uppercase",
    letterSpacing: 0.8,
    marginBottom: 2,
  },
  headerTitle: {
    fontSize: 28,
    fontFamily: "Inter_700Bold",
  },
  loading: { flex: 1, alignItems: "center", justifyContent: "center" },
  listContent: {
    paddingHorizontal: 20,
    paddingTop: 4,
  },
  sectionLabel: {
    fontSize: 14,
    fontFamily: "Inter_500Medium",
    marginBottom: 14,
  },
  reportCard: {
    flexDirection: "row",
    alignItems: "center",
    padding: 16,
    borderRadius: 16,
    marginBottom: 12,
    gap: 12,
    shadowColor: "rgba(0,0,0,0.06)",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 3,
  },
  iconBox: {
    width: 48,
    height: 48,
    borderRadius: 12,
    alignItems: "center",
    justifyContent: "center",
  },
  cardText: { flex: 1 },
  carName: {
    fontSize: 16,
    fontFamily: "Inter_700Bold",
    marginBottom: 2,
  },
  plate: {
    fontSize: 13,
    fontFamily: "Inter_500Medium",
  },
});
